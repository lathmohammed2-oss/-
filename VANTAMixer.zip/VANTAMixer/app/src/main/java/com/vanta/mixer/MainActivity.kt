package com.vanta.mixer

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioTrack.Builder
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private var running = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    @Volatile private var gain = 1.0f
    @Volatile private var echo = 0.0f
    @Volatile private var bass = 0.0f
    @Volatile private var deep = 0.0f
    private var lastSample = 0.0f
    private var echoState = 0.0f
    private lateinit var status: TextView
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(9, 11, 14))
        }
        val title = TextView(this).apply {
            text = "VANTA  /  MIXER"
            textSize = 27f
            setTextColor(Color.rgb(182, 255, 59))
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        root.addView(title)
        root.addView(label("LIVE VOICE PROCESSOR  •  ANDROID"))
        status = label("الحالة: متوقف")
        status.setTextColor(Color.LTGRAY)
        status.setPadding(0, 20, 0, 14)
        root.addView(status)
        startButton = Button(this).apply {
            text = "تشغيل مراقبة الصوت"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(182, 255, 59))
            setOnClickListener { toggleAudio() }
        }
        root.addView(startButton)
        root.addView(label("مستوى الصوت"))
        addSlider(root, "GAIN", 0, 200, 100) { gain = it / 100f }
        root.addView(label("عمق الصوت (تأثير أولي)"))
        addSlider(root, "DEEP", 0, 100, 0) { deep = it / 100f }
        root.addView(label("الصدى"))
        addSlider(root, "ECHO", 0, 70, 0) { echo = it / 100f }
        root.addView(label("دفء / باس"))
        addSlider(root, "BASS", 0, 100, 0) { bass = it / 100f }
        val note = TextView(this).apply {
            text = "ملاحظة: هذه النسخة تعالج المايك داخل التطبيق وتراقب الصوت عبر مخرج الجهاز. لا تحقن الصوت تلقائياً داخل TikTok أو Messenger أو المكالمات النظامية."
            textSize = 13f
            setTextColor(Color.rgb(170, 177, 187))
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(0, 12, 0, 2)
    }

    private fun addSlider(root: LinearLayout, name: String, min: Int, max: Int, initial: Int, onValue: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val nameView = TextView(this).apply { text = name; textSize = 12f; setTextColor(Color.rgb(182,255,59)); minWidth = 58 }
        val seek = SeekBar(this).apply { this.max = max - min; progress = initial - min }
        row.addView(nameView)
        row.addView(seek, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) = onValue(progress + min)
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun toggleAudio() {
        if (running) { stopAudio(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }
        startAudio()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
    }

    private fun startAudio() {
        val rate = 44100
        val inputMin = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val outputMin = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (inputMin <= 0 || outputMin <= 0) { toast("تعذر تهيئة الصوت على هذا الجهاز"); return }
        try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(inputMin, 4096) * 2)
            player = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(outputMin, 4096) * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            recorder?.startRecording(); player?.play()
            running = true
            startButton.text = "إيقاف مراقبة الصوت"
            status.text = "الحالة: يعمل • استخدم سماعة لتجنب الصفير"
            worker = thread(name = "VantaAudio") {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                val input = ShortArray(1024); val output = ShortArray(1024)
                while (running) {
                    val count = recorder?.read(input, 0, input.size) ?: -1
                    if (count > 0) {
                        for (i in 0 until count) {
                            val x = input[i] / 32768f
                            val low = lastSample + 0.08f * (x - lastSample)
                            lastSample = low
                            var y = x * (1f - bass) + low * bass * 2.0f
                            echoState = y + echoState * 0.55f
                            y = y * (1f - echo) + echoState * echo
                            // Conservative tonal shaping; true pitch shifting needs a dedicated DSP engine.
                            y *= (1f + deep * 0.08f)
                            y *= gain
                            output[i] = (y.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                        }
                        player?.write(output, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            stopAudio(); toast("فشل تشغيل الصوت: ${e.message ?: "خطأ غير معروف"}")
        }
    }

    private fun stopAudio() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release(); recorder = null; player = null
        startButton.text = "تشغيل مراقبة الصوت"
        status.text = "الحالة: متوقف"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { stopAudio(); super.onDestroy() }
}
