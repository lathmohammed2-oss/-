# VANTA Mixer (Android prototype)

A native Android Studio starter project for real-time microphone monitoring with basic gain, echo, and low-frequency emphasis controls.

## Build
- Open this folder in Android Studio (Hedgehog or newer).
- Allow Gradle sync to download Android Gradle Plugin 8.10.1 and Kotlin plugin 2.0.21.
- Build > Build APK(s), then install the debug APK on the phone.

## Important limits
- This prototype processes microphone audio only inside this app and plays the result through the selected media output.
- Android does not provide a normal public API for injecting an app's processed microphone stream into arbitrary third-party apps or cellular calls. TikTok/Messenger integration would require a supported external audio route, compatible hardware, or platform-specific capabilities.
- `DEEP` is conservative tonal shaping, not a true pitch shifter yet. Echo/bass are basic prototype DSP, not studio-grade effects.
- Use headphones while monitoring to avoid feedback.
